/*
    Module: net_gateway.cpp
    Author: Gary Conway <gary.conway@fireking.com>
    Created: 12-14-2017
    Revised:
    Compiler: C++
    Platform: Linux (Ubuntu)
    Notice: Copyright 2017 FireKing Security Group

    Version: 1.0

	This module is the interface between the business logic and the network

*/


