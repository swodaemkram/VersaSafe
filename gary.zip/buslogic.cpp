/*

    Program: VersaSafe
    Module: buslogic.cpp
    Author: Gary Conway <gary.conway@fireking.com>
    Created: 12-1-2017
    Updated:
    Language: C,C++ (this module is C++ compilable and linkable with C libs)
    Version: 1.00


	This module handles the business logic of the safe

*/



